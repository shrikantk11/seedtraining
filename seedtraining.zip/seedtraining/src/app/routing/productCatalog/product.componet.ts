import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'product-app',
    template: `
    <h4 class="text-center">Product Catalog </h4><hr>
    <a [routerLink]="['./list']">Product List</a> |
    <a [routerLink]="['./create']">Product Create</a> | 
    <a [routerLink]="['./list/:id']">Product List</a> |
    <a [routerLink]="['./update/:id']">Product Update</a> | 
    <a [routerLink]="['./delete/:id']">Product Delete</a>  |
    <hr>
    <div>
        
        <router-outlet></router-outlet>
    </div>
    `,
    styles: [``]
})
export class ProductComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
