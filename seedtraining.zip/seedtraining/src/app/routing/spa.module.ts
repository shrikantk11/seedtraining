import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { Routes, RouterModule } from "@angular/router";

import { LoggedInGuard } from "./loggedinguardservice";
import { AuthService } from "./authservice";
 
import { HomeComponent } from "./root/home/home.component";
import { AboutusComponent } from "./root/aboutus/aboutus.component";
import { ContactComponent } from "./root/contact/contact.component";
import { ProductListComponent } from "./productCatalog/product-list/product-list.component";
import { ProductDetailComponent } from "./productCatalog/product-detail/product-detail.component";
import { PagenotfoundComponent } from "./root/pagenotfound/pagenotfound.component";
import { ProductUpdateComponent } from "./productCatalog/product-update/product-update.component";
import { ProductCreateComponent } from "./productCatalog/product-create/product-create.component";
import { ProductDeleteComponent } from "./productCatalog/product-delete/product-delete.component";

import { ProtectedComponent } from "./root/protected/protected.component";
import { BarchartComponent } from "./bi/barchart/barchart.component";
import { PiechartComponent } from "./bi/piechart/piechart.component";
import { DashboardComponent } from "./bi/dashboard/dashboard.component";
import { SignInComponent } from "./sign-in/sign-in.component";
import { SPAComponent} from "./spa.component";
import { ProductComponent } from "./productCatalog/product.componet";
@NgModule({
    declarations: [
        SPAComponent,
        HomeComponent, AboutusComponent, ContactComponent,
        ProductListComponent , ProductDetailComponent,
        PagenotfoundComponent, ProductUpdateComponent,
        ProductCreateComponent,ProductDeleteComponent,
        ProductComponent,
        DashboardComponent,PiechartComponent,BarchartComponent,
        SignInComponent,
        ProtectedComponent,
    ],
    exports: [
        HomeComponent, AboutusComponent, ContactComponent,
        ProductListComponent , ProductDetailComponent,
        PagenotfoundComponent, ProductUpdateComponent,ProductCreateComponent,
        ProductDeleteComponent,SPAComponent,ProductComponent,
     
        DashboardComponent,PiechartComponent,BarchartComponent,
        SignInComponent,
        ProtectedComponent
    ],
    imports:[
        BrowserModule,
        FormsModule,
        RouterModule
    ],

    providers:[AuthService,LoggedInGuard ],
})
export class SPAModule{}