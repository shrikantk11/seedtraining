import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'revenue-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.css']
})
export class PiechartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
