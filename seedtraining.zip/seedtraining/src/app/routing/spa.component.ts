import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'spa',
    template: `
    <div class="container-fluid mb-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card" style="padding:4px 0px 5px 0px;">
                    <nav class="nav NavBarLink nav-justified d-flex nav-stacked">
                    <a class="nav-item nav-link" [routerLink]="['./home']" routerLinkActive="active">Home</a> 
                    <a class="nav-item nav-link" [routerLink]="['./about']" routerLinkActive="active">About</a> 
                    <a class="nav-item nav-link" [routerLink]="['./contact']" routerLinkActive="active">Contact</a> 
                    <a class="nav-item nav-link" [routerLink]="['./protected']" routerLinkActive="active">Protected</a> 
                    <a class="nav-item nav-link" [routerLink]="['./dashboard']" routerLinkActive="active">Dashboard </a> 
                    <a class="nav-item nav-link" [routerLink]="['./signIn']" routerLinkActive="active">SignIn </a> 
                    <a class="nav-item nav-link" [routerLink]="['./Product']" routerLinkActive="active">Product Catalog</a> 
                    </nav>
                </div>
            </div>
        </div> 
    </div>
    <router-outlet></router-outlet>
       
    `,
    styles: [``]
})
export class SPAComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
