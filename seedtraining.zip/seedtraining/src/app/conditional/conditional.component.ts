import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conditional',
  templateUrl: './conditional.component.html',
  styleUrls: ['./conditional.component.css']
})
export class ConditionalComponent implements OnInit {
  public billingPrice;
  public productionConst:number;
  public flower:string;
  public bestflower:string;

  constructor() {
    this.productionConst=665;
    this.billingPrice=1123;
    this.flower='gerbera';
    this.bestflower='rose';
   }

   isFlowerAvailable(): boolean {return true}
  ngOnInit() {
  }

}
