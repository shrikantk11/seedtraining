import { Directive, HostListener, Renderer, ElementRef } from '@angular/core';

@Directive({
    selector: '[rolling]'
})
export class RollingDirective {
    constructor(private renderer: Renderer,private el: ElementRef){}
    
    @HostListener('mouseenter') onMouseEnter() { this.hover(true); }
    @HostListener('mouseleave') onMouseLeave() { this.hover(false); }

    hover(shouldUnderline: boolean){
        if(shouldUnderline){  
        this.renderer.setElementStyle(this.el.nativeElement, 'transform', 'rotate(20deg)');
        } else {         
        this.renderer.setElementStyle(this.el.nativeElement, 'transform', 'rotate(0deg)');
        }
    }
}