import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { SellingflowersPipe } from "./sellingflowerpipe";
import { HiddenDirective } from "./customdirectivehidden";
import { IfDirective } from "./customdirectiveif";
import { UnderlineDirective } from "./customdirectiveunderline";
import { RollingDirective } from "./customRolling";
import { DefaultImage } from "./DefaultImage";

 
@NgModule({
    declarations: [ 
                    DefaultImage,
                    SellingflowersPipe,
                    HiddenDirective,
                    IfDirective,
                    UnderlineDirective,
                    RollingDirective
                ],
    exports: [      SellingflowersPipe,
                    HiddenDirective,
                    IfDirective,
                    UnderlineDirective,
                    RollingDirective,
                    DefaultImage,
             ],
    imports:[ BrowserModule],

    providers:[ ],
})
export class CustomModule{}