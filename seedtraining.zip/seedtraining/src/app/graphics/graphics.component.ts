import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'graphics',
    template: `
        <div class="container-fluid mt-3">
        <h4 class="text-center text-capatalise">Graphical Shapes</h4><hr>
            <div class="row justify-content-center">
                <div class="col-sm-3">
                    <p>Square</p>
                    <rect [size]="300" [color]="'blue'" 
                        [x1]="20" [y1]="30" 
                        [x2]="200" [y2]="200" > 
                    </rect>  
                </div>
                <div class="col-sm-3">
                    <p>Line</p>
                    <line [size]="300" [color]="'red'" 
                        [x1]="20" [y1]="30" [x2]="200" [y2]="200"> 
                    </line>
                </div>
                <div class="col-sm-3">
                    <p>Smiley</p>
                    <gdi></gdi>
                </div>
                <div class="col-sm-3">
                    <p>Ellipse</p>
                    <ellipse [size]="100" [color]="'red'"> </ellipse>
                </div>
            </div> 
        </div> 
    `,
    styles: [``]
})
export class GraphicsComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
