import { Routes } from "@angular/router";
import { CatalogComponent } from "./catalog/catalog.comonent";
import { EmailFormComponent } from "./crm/email-form/email-form.component";
import { ReactiveformComponent } from "./crm/reactiveform/reactiveform.component";
import { TemplatedrivenformComponent } from "./crm/templatedrivenform/templatedrivenform.component";
import { CustomerAddressComponent } from "./crm/customer-address/customer-address.component";
import { ProductlistComponent } from "./catalog/productlist/productlist.component";
import { CatalogModule } from "./catalog/catalogmodule";
import { GraphicsComponent } from "./graphics/graphics.component";
import { GitHTTPComponent } from "./HTTP/git-http/git-http.component";
import { LoginComponent } from "./secure/login/login.component";
import { BrandingComponent } from "./branding/branding.component";
import { ConditionalComponent } from "./conditional/conditional.component";
import { PagenotfoundComponent } from "./routing/root/pagenotfound/pagenotfound.component";
import { ProductInsertComponent } from "./catalog/product-insert/product-insert.component";
import { ProductDeleteComponent } from "./catalog/product-delete/product-delete.component";
import { SellingProductsComponent } from "./catalog/selling-products/selling-products.component";
import { GDIComponent } from "./graphics/gdi/gdi.component";
import { SmileyComponent } from "./graphics/smiley/smiley.component";
import { SecureComponent } from "./secure/secure.component";
import { RegisterComponent } from "./secure/register/register.component";
import { SignInComponent } from "./secure/sign-in/sign-in.component";
import { ChangepasswordComponent } from "./secure/changepassword/changepassword.component";
import { RevenueDashboardComponent } from "./BI/revenue-dashboard/revenue-dashboard.component";
import { HomeComponent } from "./routing/root/home/home.component";
import { AboutusComponent } from "./routing/root/aboutus/aboutus.component";
import { ContactComponent } from "./routing/root/contact/contact.component";
import { ProductCreateComponent } from "./routing/productCatalog/product-create/product-create.component";
import { ProductUpdateComponent } from "./catalog/product-update/product-update.component";
import { ProductDetailComponent } from "./routing/productCatalog/product-detail/product-detail.component";
import { ProtectedComponent } from "./routing/root/protected/protected.component";
import { DashboardComponent } from "./routing/bi/dashboard/dashboard.component";
import { LoggedInGuard } from "./routing/loggedinguardservice";
import { BarchartComponent } from "./routing/bi/barchart/barchart.component";
import { PiechartComponent } from "./routing/bi/piechart/piechart.component";
import { SPAComponent } from "./routing/spa.component";
import { ProductComponent } from "./routing/productCatalog/product.componet";
import { ProductListComponent } from "./routing/productCatalog/product-list/product-list.component";
import { DirectiveComponent } from "./directive/directive.component";
export const catalogchildRoutes: Routes = [
    { path: '', redirectTo: 'ProductList', pathMatch: 'full' },
    { path: 'ProductList', component: ProductlistComponent},
    { path: 'ProductInsert', component: ProductInsertComponent},
    { path: 'ProductDelete', component: ProductDeleteComponent},
    { path: 'SellingProduct', component: SellingProductsComponent},
  ];
export const securechildRoutes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent},
    { path: 'signin', component: SignInComponent},
    { path: 'register', component: RegisterComponent},
    { path: 'changepasswd', component: ChangepasswordComponent},
  ];
export const dashboardRoutes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'bar', component: BarchartComponent },
    { path: 'pie', component: PiechartComponent},
  ];
export const catalogRoutes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  {path: 'list', component: ProductListComponent},
  {path: 'detail', component: ProductDetailComponent},
  {path: 'create', component: ProductCreateComponent},
  {path: 'list/:id', component:  ProductlistComponent},
  {path: 'update/:id', component: ProductUpdateComponent},
  {path: 'delete/:id', component: ProductDeleteComponent},
]
export const routingRoutes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {path: 'home', component: HomeComponent },
  {path: 'about', component:AboutusComponent },
  {path: 'contact',component: ContactComponent },
  {path: 'signIn',component: SignInComponent },
  {path: 'Product',component: ProductComponent, children:catalogRoutes },
  {path: 'protected',component: ProtectedComponent,canActivate: [LoggedInGuard] },
  {path: 'dashboard', component: DashboardComponent,children:dashboardRoutes}
]

export const appRoutes: Routes = [
  { path: '', redirectTo: '/Catalog/ProductList', pathMatch: 'full'},
  { path: 'Catalog', component: CatalogComponent, children:catalogchildRoutes},
  { path: 'EmailForm',   component: EmailFormComponent },
  { path: 'ReactiveForm',component: ReactiveformComponent},
  { path: 'TemplateForm',component: TemplatedrivenformComponent},
  { path: 'CustomerAddress', component: CustomerAddressComponent},
  { path: 'Graphics', component: GraphicsComponent},
  { path: 'HTTP', component: GitHTTPComponent},
  { path: 'Secure', component: SecureComponent, children:securechildRoutes},
  { path: 'Branding', component: BrandingComponent},
  { path: 'Conditional', component: ConditionalComponent},
  { path: 'Charts', component: RevenueDashboardComponent},
  { path: 'Directives', component: DirectiveComponent},
  {path: 'routing', component: SPAComponent,children:routingRoutes},

  { path: '**', component: PagenotfoundComponent },
];

