export class User {
                    username: string;
                    password: string;
                    mobileNumber: string;
                    email: string;
}