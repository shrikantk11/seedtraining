import { Component, OnInit } from '@angular/core';
import { GithubAPIService } from '../githubapiservice';
import { User } from './user';

@Component({
  selector: 'git-http',
  templateUrl: './git-http.component.html',
  styleUrls: ['./git-http.component.css']
})
export class GitHTTPComponent implements OnInit {
  userName:string=null;
  data: Object;
  loading : boolean=false;
  getall : boolean=true;
  noData : boolean=false;
  user:User; 
  constructor(private svc: GithubAPIService) {
  this.user=new User("","","","","");
  }
  ngOnInit() {
    this.getAll();
  }


  makeRequest(): void {
    //this.user=this.svc.getUser("ravitambade");
    if(this.userName!=null){
      this.svc.getUser(this.userName).subscribe(usr => { 
        this.user = usr;
        this.data=usr;
        this.noData = false; 
        this.getall = false;
        console.log(usr);
        this.loading = true;
        },err=>{
             this.loading = false;
             this.noData = true; 
             this.getall = false;
          console.log(err.statusText)
      });
    }else{
      console.log("input not given");
    }
    
  }


  getAll(){
    this.getall = true;
    this.loading = false;
    this.noData = false; 
    this.svc.getAllUser().subscribe(usr => { 
      this.user = usr;
      this.data=usr;
      console.log(usr)
      },err=>{
        console.log(err)
    });

  }
}