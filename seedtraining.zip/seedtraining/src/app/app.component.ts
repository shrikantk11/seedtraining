import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  status="false";
  title = 'Angular 5 Training'; // Member variable
  fname = 'Shrikant';
  lname = ' K';
  product: any = {
    title: 'Angular',
    duaration: 4,
    fees: 20000
  };
  isbasicInfo=false;
  isLogin=false;
  isBranding=false;
  isConditional=false;
  isProductList=true;
  isSelling=false;
  isSignIn=false;
  isGraphics=false;
  isTemplate=false;
  isReactive=false;

  basicInfo():any{
      this.isbasicInfo = !this.isbasicInfo;
  }
  login():any{
      this.isLogin = !this.isLogin;
  }
  branding():any{
      this.isBranding = !this.isBranding;
  }
  conditional():any{
      this.isConditional = !this.isConditional;
  }
  productList():any{
      this.isProductList = !this.isProductList;
  }
  SellingList():any{
      this.isSelling = !this.isSelling;
  }
  SignIn():any{
      this.isSignIn = !this.isSignIn;
  }
  graphics():any{
      this.isGraphics = !this.isGraphics;
  }
  reactiveForm():any{
      this.isReactive = !this.isReactive;
  }
  templateForm():any{
      this.isTemplate = !this.isTemplate;
  }
}
