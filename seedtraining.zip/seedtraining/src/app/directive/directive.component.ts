import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive',
  template: `
    <h4 class="mt-3">
      Custom Directive => [myHidden] , *myIf, 
    </h4>
    <h5 [hidden]="false"  >Welcome to transflower</h5>
    <ol [myHidden]="false" class="list-inline">
      <li class="list-inline-item">Rose</li>
      <li class="list-inline-item">Jasmine</li>
      <li class="list-inline-item">Lotus</li>
      <li class="list-inline-item">Rose</li>
    </ol>
    <ol *myIf="true"  class="list-inline">
      <li class="list-inline-item">Rose</li>
      <li class="list-inline-item">Jasmine</li>
      <li class="list-inline-item">Lotus</li>
      <li class="list-inline-item">Rose</li>
    </ol>
    <ol class="list-inline">
       <li class="list-inline-item">Rose</li>
       <li class="list-inline-item">Jasmine</li>
       <li class="list-inline-item">Lotus</li>
       <li class="list-inline-item">Rose</li>
     </ol> 
  `,
  styles: []
})
export class DirectiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
