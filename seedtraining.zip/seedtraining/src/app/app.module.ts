import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { CommonModule} from '@angular/common';
import { AppComponent } from './app.component';
import { BrandingComponent } from './branding/branding.component';
import { ConditionalComponent } from './conditional/conditional.component';
import { CatalogModule } from "./catalog/catalogmodule";
import { CustomModule} from "./custom/custommodule";
import { SecureModule } from './secure/securemodule';
import { GraphicsModule } from "./graphics/graphics.module";
import { CRMModule} from './crm/crmmodule';
import { AppNavComponent } from './app-nav/app-nav.component'
import { GitHttpModule } from './HTTP/githttp.module';
import { BIModule } from './BI/bi.module';
import { RouterModule,Routes} from '@angular/router';
import { appRoutes } from "./routeConfig";
import { SPAModule } from "./routing/spa.module";
import { AppFooterComponent } from './app-footer/app-footer.component';
import { DirectiveComponent } from './directive/directive.component';
@NgModule({
  declarations: [
    AppComponent,
    BrandingComponent,
    ConditionalComponent,
    AppNavComponent,
    AppFooterComponent,
    DirectiveComponent,
  ],
  imports: [
    CatalogModule,
    BrowserModule,
    FormsModule,
    CommonModule,
    CustomModule,
    SecureModule,
    GraphicsModule,
    CRMModule,
    GitHttpModule,
    BIModule,
    SPAModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
