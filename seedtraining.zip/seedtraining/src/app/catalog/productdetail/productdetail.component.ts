import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {

  @Input() name:string;
  @Input() price:number;
  @Input() quantity:number;
  @Input() imageUrl:string;
  @Input() likes:number;
  @Input() i:number;

  default="assets/noImage.png";
  constructor() { }

  ngOnInit() {
  }

  order(){
    console.log("Your Order has been Submitted");
  }

  setDefault() {
  this.imageUrl = "assets/noImage.png";
  }

  counterUpdate(ee:any){
    this.likes=ee.count;
  }
}
