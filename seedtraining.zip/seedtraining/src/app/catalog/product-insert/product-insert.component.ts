import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'product-insert',
  templateUrl: './product-insert.component.html',
  styleUrls: ['./product-insert.component.css']
})
export class ProductInsertComponent implements OnInit {

  private currentflower;
  submit=false;
  private model={
    title:"Rose",
    description:"Valentine Flower",
    price:5,
    quantity:500,
    url:"http://flowers.com/best/rose.jpg"
  };

  constructor() { }

  ngOnInit() {
  }

  onSubmit(){
    this.submit=true;
    this.currentflower=this.model;
  }

}
