import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'catalog ',
    templateUrl: './catalog.component.html'
})
export class CatalogComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
