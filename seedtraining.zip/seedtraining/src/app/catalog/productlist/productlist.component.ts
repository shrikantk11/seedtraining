import { Component, OnInit } from '@angular/core';
import { ProductService } from "../productservice";
import { Product } from '../product';
@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css'],
  providers:[ProductService]
})
export class ProductlistComponent implements OnInit {
  // flowersArary=["Rose","Lilly","Lotus","Jasmine","Marigold","Aster"]
  // flowerArary=[
  //   {
  //     name:"Rose",
  //     price:500,
  //     quantity:25,
  //     likes:122,
  //     imageUrl:"/assets/image/rose.jpeg"
  //   },
  //   {
  //     name:"marigload",
  //     price:100,
  //     quantity:53,
  //     likes:123,
  //     imageUrl:"/assets/image/marigold.jpg"
  //   },
  //   {
  //     name:"Lotus",
  //     price:800,
  //     quantity:51,
  //     likes:102,
  //     imageUrl:"/assets/image/lotus.jpg"
  //   },
  // ]

  flowerArary=[];
  constructor(private service:ProductService){
    }

  ngOnInit() {
    this.service.getProducts().subscribe(product=>{
      this.flowerArary=product;
    });
    console.log('flowers :', this.flowerArary);
  }

}
