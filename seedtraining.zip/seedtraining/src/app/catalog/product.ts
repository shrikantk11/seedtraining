export class Product{
constructor( private name:string,
             private quantity:number,
             private price:number,
             private likes:number,
             private imageUrl:string){}
}