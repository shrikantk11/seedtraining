import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { CommonModule} from '@angular/common';
import { ProductdetailComponent } from './productdetail/productdetail.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { CounterComponent } from './counter/counter.component';
import { SellingProductsComponent } from './selling-products/selling-products.component';
import { ProductService } from "./productservice";
import { ProductDeleteComponent } from './product-delete/product-delete.component';
import { ProductInsertComponent } from './product-insert/product-insert.component';
import { ProductUpdateComponent } from './product-update/product-update.component';
import { CustomModule } from "../custom/custommodule";
import { CatalogComponent } from "./catalog.comonent";
import { Routes, RouterModule } from "@angular/router";
import { HttpClientModule } from '@angular/common/http';
@NgModule({
   declarations: [
        CatalogComponent,
        ProductdetailComponent,
        ProductlistComponent,
        CounterComponent,
        SellingProductsComponent,
        ProductInsertComponent,
        ProductDeleteComponent,
        ProductUpdateComponent
    ],
    exports:[
        CatalogComponent,
        ProductdetailComponent,
        ProductlistComponent,
        CounterComponent,
        SellingProductsComponent,
        ProductInsertComponent,
        ProductDeleteComponent,
        ProductUpdateComponent
    ],
    imports:[
        BrowserModule,
        FormsModule,
        CommonModule,
        CustomModule,
        RouterModule,
        HttpClientModule
    ],
    providers:[ProductService]
})

export class CatalogModule{

}
