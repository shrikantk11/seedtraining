import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from "@angular/core";
import { Product } from './product';
import { tap } from 'rxjs/operators';

@Injectable()
export class ProductService{
    constructor(private http:HttpClient){
        console.log("constructor is invoked");
    }

    getProducts  (): Observable<any> {
      return this.http.get('../../assets/json/flowers.json').pipe(
          tap(product => console.log(`fetched `))
        );
    }
}
