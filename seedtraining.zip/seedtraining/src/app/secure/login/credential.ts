
 export class Credential{

    private userName:string;
    private password:string;

    private status:boolean=false;

    constructor(){
     this.userName="ravi";
     this.password="seed";
    }
    public validate(name:string,pass:string):boolean{ 
        if(name=="ravi" && pass=="kavi"){
            this.status=true;
        }
        return this.status;
    }
}