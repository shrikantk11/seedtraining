import { RouterModule } from '@angular/router';
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { LoginComponent } from "./login/login.component";
import { ChangepasswordComponent } from "./changepassword/changepassword.component";
import { SignInComponent } from "./sign-in/sign-in.component";
import { AuthService } from "./authservice";
import { RegisterComponent } from "./register/register.component";
import { SecureComponent } from './secure.component';

 
@NgModule({
    declarations: [LoginComponent,
                   ChangepasswordComponent,
                   SignInComponent,
                   RegisterComponent,
                   SecureComponent
                ],
    
    exports: [     LoginComponent,
                   ChangepasswordComponent,
                   SignInComponent,
                   RegisterComponent,
                   SecureComponent
             ],

    imports:[
            BrowserModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule
    ],

    providers:[ 
        AuthService
    ],
})
export class SecureModule{}