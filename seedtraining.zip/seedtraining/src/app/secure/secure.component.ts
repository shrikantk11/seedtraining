import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'secure',
    template: `
    <div class="container-fluid mb-4">
        <div class="row justify-content-center">
            <div class="col-sm-7">
                <div class="card p-2">
                    <nav class="nav nav-justified d-flex nav-stacked">
                        <a class="nav-item nav-link" [routerLink]="['./login']" routerLinkActive="active">Login Component</a> 
                        <a class="nav-item nav-link" [routerLink]="['./signin']" routerLinkActive="active">Sign In Component</a> 
                        <a class="nav-item nav-link" [routerLink]="['./register']" routerLinkActive="active">Register Component</a> 
                        <a class="nav-item nav-link" [routerLink]="['./changepasswd']" routerLinkActive="active">Change Password </a> 
                    </nav>
                </div>
            </div>
        </div> 
    </div>
    <router-outlet></router-outlet>
    `,
    styles: [``]
})
export class SecureComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
