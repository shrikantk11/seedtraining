import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";


@NgModule({
    declarations: [
    ],
    exports: [
    ],
    imports:[
        BrowserModule
    ],

    providers:[ ],
})
export class SharedModule{}